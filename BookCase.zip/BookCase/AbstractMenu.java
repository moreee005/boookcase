package BookCase;
//AbstractMenu.java
public interface AbstractMenu {
void showMenu();
}


